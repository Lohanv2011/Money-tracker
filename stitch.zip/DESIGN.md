# Design System Document: The Editorial Mint

## 1. Overview & Creative North Star

### Creative North Star: "The Tactile Ledger"
Moving away from the sterile, spreadsheet-like nature of traditional finance apps, this design system treats personal finance as a curated, tactile experience. We are building a "Tactile Ledger"—an interface that feels as soft as high-quality paper and as intuitive as a physical wallet. 

To break the "standard mobile app" mold, we move beyond rigid grids. We embrace **Intentional Asymmetry** (e.g., offsetting a large display-lg balance against a smaller label-md status) and **Floating Surfaces**. By utilizing a "Mint-on-Mint" color palette, we create a breathable, high-end environment where data feels light rather than burdensome.

---

## 2. Colors

The palette is anchored in a lush, organic green that communicates growth, contrasted with a sophisticated editorial red for outflows.

### The "No-Line" Rule
**Prohibit 1px solid borders for sectioning.** Structural separation is achieved exclusively through background shifts. For example, a card using `surface-container-lowest` sits on a background of `surface`. If a section needs to feel recessed, use `surface-container-high`.

### Surface Hierarchy & Nesting
Treat the UI as a series of nested, physical layers. 
- **Base Layer:** `surface` (#ddffe2)
- **Content Groupings:** `surface-container-low` (#cafdd4)
- **Interactive Cards:** `surface-container-lowest` (#ffffff)
- **Deep Recesses:** `surface-dim` (#a0e4b1)

### The "Glass & Gradient" Rule
Floating elements (like a Bottom Navigation Bar or a persistent "Add Expense" button) should use **Glassmorphism**. Apply `surface-container-lowest` at 80% opacity with a `24px` backdrop-blur. 
For primary actions, move beyond flat green: use a subtle linear gradient from `primary` (#176a21) to `primary_container` (#9df197) at a 135-degree angle to provide "visual soul."

---

## 3. Typography

The system uses a dual-font strategy to balance character with extreme legibility.

*   **Display & Headlines (Plus Jakarta Sans):** Chosen for its geometric precision and modern "friendly" curves. Use `display-lg` for the total balance to make it a hero element.
*   **Body & Labels (Manrope):** A highly functional sans-serif that excels in numeric data. Manrope’s tabular figures ensure that fluctuating money amounts don't cause layout "jitter."

**Hierarchy as Identity:**
- **The "Hero" Stat:** `display-md` (Plus Jakarta Sans) in `on_surface`.
- **The "Narrative" Label:** `label-md` (Manrope) in `on_surface_variant` with 0.05em letter spacing for an editorial feel.

---

## 4. Elevation & Depth

We eschew traditional drop shadows in favor of **Tonal Layering**.

*   **The Layering Principle:** Depth is "stacked." To elevate a transaction card, do not add a shadow; instead, place a `surface-container-lowest` (#ffffff) card against the `surface` (#ddffe2) background. The 40-unit difference in lightness provides a soft, natural lift.
*   **Ambient Shadows:** If an element must float (e.g., a modal or FAB), use a shadow with a `32px` blur, 0px offset, and 6% opacity using the `on_surface` color (#0b361d). This creates an "atmospheric" glow rather than a harsh edge.
*   **The "Ghost Border" Fallback:** For high-density data, use a "Ghost Border": the `outline_variant` token at **15% opacity**. Never use a 100% opaque border.

---

## 5. Components

### Buttons
- **Primary (The Growth Action):** Uses the `primary` to `primary_container` gradient. `xl` (1.5rem) rounded corners. Text in `on_primary`.
- **Secondary (The Spending Action):** `secondary` (#b5161e) background with `on_secondary` text. Used for "Add Expense."

### Cards & Lists
- **The "Line-Free" List:** Forbid divider lines. Separate transactions using `12px` of vertical whitespace and a subtle shift to `surface-container-low` on every second item to create a rhythmic, zebra-stripe effect that feels intentional, not cluttered.
- **Corner Strategy:** Apply `lg` (1rem) for containers and `md` (0.75rem) for nested elements.

### Input Fields
- **The "Quiet" Input:** No bottom line or box. Inputs should be `surface-container-highest` with a soft `md` corner. Focus state is indicated by a "Ghost Border" of `primary` at 40% opacity.

### Additional Signature Component: The "Growth Bar"
A custom progress component for savings goals. Use `primary_container` as the track and a `primary` to `inverse_primary` gradient for the fill. No hard edges—always `full` rounded corners.

---

## 6. Do's and Don'ts

### Do
- **Do** use `secondary` (#b5161e) for all currency values that represent an outflow, but keep the accompanying label in `on_surface_variant` to maintain sophistication.
- **Do** allow for generous white space. If a screen feels full, increase the spacing between groups rather than adding a divider.
- **Do** use `surface_bright` for peak highlights in empty states to guide the user's eye.

### Don't
- **Don't** use pure black (#000000) for text. Always use `on_surface` (#0b361d) to maintain the organic, "forest-tinted" editorial feel.
- **Don't** use standard `0.5rem` corners for everything. Mix `xl` for large cards and `md` for smaller chips to create a "nested" visual interest.
- **Don't** use haptic-feedback vibrations for every tap. Save them for "Success" (Income) and "Alert" (Overspending) to give the digital experience a physical weight.